/***
 * definicao do aplicativop
 */

// tipo de app 0 - usuario final 1 - van
angular._app_type = 0;

var appYellos = angular.module('appYellos', ['ngRoute','ngMaterial', 'ngMessages','ui','uiGmapgoogle-maps']) //, 'material.svgAssetsCache'
	// Configuracoes
	.config(['$routeProvider',function($routerProvider,$locationProvider)
	{
		return $routerProvider
			.when('/', {templateUrl: 'views/home/index.html', controller: 'mainController'})
			.when('/home', {templateUrl: 'views/home/menu.html', controller: 'mainController'})
			.when('/login', {templateUrl: 'views/home/login.html', controller: 'mainController'})
			.when('/selecionacadastro', {templateUrl: 'views/home/selCadastro.html', controller: 'mainController'})
			.when('/cadastro', {templateUrl: 'views/home/cadastro.html', controller: 'mainController'})
			.when('/main', {templateUrl: 'views/home/main.html', controller: 'mainController'})

			.when('/main', {templateUrl: 'views/home/main.html', controller: 'mainController'})

			.when('/user', {templateUrl: 'views/user/show.html', controller: 'userController'})
			.when('/user/upload', {templateUrl: 'views/user/upload.html', controller: 'userController'})

			.when('/mensagem', {templateUrl: 'views/mensagens/list.html', controller: 'mensagemController'})
			.when('/mensagem/edit', {templateUrl: 'views/mensagens/edit.html', controller: 'mensagemController'})
			.when('/mensagem/edit/:to/:nome/:title/:body/:extra', {templateUrl: 'views/mensagens/edit.html', controller: 'mensagemController'})

			.when('/alerta', {templateUrl: 'views/mensagens/list.html', controller: 'mensagemController'})

			.when('/bairro', {templateUrl: 'views/bairro/list.html', controller: 'bairroController'})
			.when('/bairro/edit', {templateUrl: 'views/bairro/edit.html', controller: 'bairroController'})

			.when('/escola', {templateUrl: 'views/escola/list.html', controller: 'escolaController'})
			.when('/escola/list', {templateUrl: 'views/escola/list.html', controller: 'escolaController'})
			.when('/escola/edit', {templateUrl: 'views/escola/edit.html', controller: 'escolaController'})

			.when('/crianca', {templateUrl: 'views/crianca/list.html', controller: 'criancaController'})
			.when('/crianca/edit', {templateUrl: 'views/crianca/edit.html', controller: 'criancaController'})

			.when('/condutores', {templateUrl: 'views/condutores/list.html', controller: 'condutoresController'})

			.when('/mapa', {templateUrl: 'views/mapa/index.html', controller: 'mapaController'})

			.when('/social', {templateUrl: 'views/ajuda/extern.html', controller: 'externalController'})

			.when('/ajuda', {templateUrl: 'views/ajuda/index.html', controller: 'mainController'})

			.when('/external/duvidas', {templateUrl: 'views/ajuda/extern.html', controller: 'externalController'})
			.when('/external/temos_de_uso', {templateUrl: 'views/ajuda/extern.html', controller: 'externalController'})
			.when('/external/sobre', {templateUrl: 'views/ajuda/extern.html', controller: 'externalController'})
			.when('/external/fale_conosco', {templateUrl: 'views/ajuda/extern.html', controller: 'externalController'})

			;
	}])
	.config(['uiGmapGoogleMapApiProvider',function(GoogleMapApiProviders)
	{
		GoogleMapApiProviders.configure(
		{
			china: true,
		});
	}])

	// filtros
	/*.filter("toDate", _toDate )
	.filter("porcentagem", _porcentagem )
	.filter("porcentagem2", _porcentagem2 )*/
	.filter("celnumber",_celnumber)

	// services
	.service("$sessionHandler",data_service)


	// Controles
	.controller("mainController", ['$scope','$routeParams','$location','$http', '$sessionHandler', mainController])
	.controller("menuController", ['$scope','$routeParams','$location','$http', '$sessionHandler', menuController])
	.controller("userController", ['$scope','$routeParams','$location','$http', '$sessionHandler', userController])
	.controller("mensagemController", ['$scope','$routeParams','$location','$http', '$sessionHandler', mensagemController])
	.controller("bairroController", ['$scope','$routeParams','$location','$http', '$sessionHandler', bairroController])
	.controller("escolaController", ['$scope','$routeParams','$location','$http', '$sessionHandler', escolaController])
	.controller("criancaController", ['$scope','$routeParams','$location','$http', '$sessionHandler', criancaController])
	.controller("mapaController", ['$scope','$routeParams','$location','$http', '$sessionHandler', 'uiGmapIsReady', mapaController])
	.controller("externalController", ['$scope','$routeParams','$location','$http', '$sessionHandler', 'uiGmapIsReady', externalController])
	.controller("condutoresController", ['$scope','$routeParams','$location','$http', '$sessionHandler', 'uiGmapIsReady', condutoresController])
	.controller("fileUploaderController", ['$scope','$routeParams','$location','$http', '$sessionHandler', fileUploaderController])

	// dev
	/*.run(function($rootScope, $templateCache)
		{
			$templateCache.removeAll();
			$rootScope.$on('$viewContentLoaded', function()
			{
				$templateCache.removeAll();
			});
		})*/
;
