function data_service()
{

	//this.SITE = 'http://yellos.local';
	this.SITE = 'http://yellos.com.br';
	//this.SITE = 'http://192.168.0.13';
	this.URL = this.SITE + '/wp-admin/admin-ajax.php';
	//this.URL = 'http://yellos.com.br/maxxis/wp-admin/admin-ajax.php';

	this.GMAP_API = 'AIzaSyCTEgYZ9Avv2enVHcQ6F_Pf3E-jtMWaEBA';

	this.isFirstLoad = true;

	this.dataModel = {
		user: {},
		criancas: [],
		bairros: [],
		escolas: [],
		motoristas: [],
		embarcados: []
	}

	this.mensagens = [];

	this.logout = function(next)
	{
		this.data = {
			user: {},
			criancas: [],
			bairros: [],
			escolas: [],
			motoristas: [],
			embarcados: []
		}
		if (window.localStorage)
		{
			window.localStorage.setItem('user','');
			window.localStorage.setItem('pass','');
		}
		if (next) next();
	}

	this.login = function(user,pass, next)
	{
		var dt = this;
		if (window.localStorage)
		{
			window.localStorage.setItem('user','');
			window.localStorage.setItem('pass','');
		}
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				'action': 'ym_login',
				username: user,
				password: pass
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (data.error)
				{
					if (next)
						next(false,textStatus);
					return;
				}
				angular._app_type == parseInt(data.type);
				dt.data.id = data.id;
				dt.data.user.id = parseInt(data.id);
				dt.data.user.username = data.nome;
				dt.data.user.email = data.email;
				dt.data.user.type = parseInt(data.type);//angular._app_type;
				dt.data.max_criancas = parseInt(data.max_criancas);
				data = JSON.parse(data.data);
				if (data.criancas)
					dt.data.criancas = data.criancas;
					else dt.data.criancas = [];
				if (data.bairros)
					dt.data.bairros = data.bairros;
					else dt.data.bairros = [];
				if (data.escolas)
					dt.data.escolas = data.escolas;
					else dt.data.escolas = [];
				if (data.motoristas)
					dt.data.motoristas = data.motoristas;
					else dt.data.motoristas = [];
				if (data.embarcados)
					dt.data.embarcados = data.embarcados;
					else dt.data.embarcados = [];
				console.log(dt.data);
				if (window.localStorage)
				{
					window.localStorage.setItem('user',user);
					window.localStorage.setItem('pass',pass);
				}
				next(dt,textStatus);
			},
			error: function( jqXHR, textStatus, errorThrown ) { next(false,textStatus); }
		});
	}

	this.lost_password = function(mail,next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_lost_password',
				email: mail
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next();
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.updatePosition = function(latitude,longitude)
	{
		var dt = this.data;
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_update_van',
				latitude: latitude,
				longitude: longitude,
				userID: this.data.user.id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.localizeEnd = function(end,next)
	{
		if (end.indexOf(',brasil')==-1) end += ',brasil';
		var addr = encodeURIComponent(end);
		$.ajax({
			dataType:'json',
			type:'GET',
			url:'https://maps.googleapis.com/maps/api/geocode/json?address='+addr+'&key='+this.GMAP_API,
			success: function( data, textStatus, jqXHR )
			{
				var result = {};
				try
				{
					if (data.results && data.results.length>0)
						result = data.results[0];
				} catch(e) {}
				if (next)
					next(result);
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.getCriancasListFromPai = function(id,next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_c_list',
				userID: id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.getToList = function(next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_to_list',
				userID: this.data.user.id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				//data.unshift({ID:0,display_name:'GERAL - A todos os pais'});
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.localizeVan = function(next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_van_location',
				userID: this.data.user.id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.sendMessage = function(mensagem,next)
	{
		if (!mensagem.extra)
			mensagem.extra = 0;
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_send_message',
				userID: this.data.user.id,
				to_userID:mensagem.selected_to.ID,
				title:mensagem.assunto,
				message:mensagem.texto,
				extra:mensagem.extra
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.deleteMessage = function(message,next)
	{
		//this.mensagens.length = 0;
		var self = this;
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_delete_message',
				message:message.id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				var i=0;
				for(i=0;i<self.mensagens.length;i++)
					if (self.mensagens[i].id==message.id) break;
				self.mensagens.splice(i,1);
				if (next)
					next(self.mensagens);

			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.getMessage = function(id, next)
	{
		if (id==undefined || id==null)
			id = 0;
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_message',
				userID: this.data.user.id,
				last_id: id //new Date(time).toISOString().slice(0, 19).replace('T', ' ')
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	this.getUser = function(next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_user',
				userID: this.data.user.id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	this.getUserInfo = function(id,next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_user',
				userID: id
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	this.updateUser = function(user,next)
	{
		data = user;
		data.userID = this.data.user.id;
		data.action = 'ym_set_user';
		$.ajax({
			dataType:'json',
			type:'POST',
			data:data,
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				console.log(data);
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	
	
	this.get = function()
	{
		if (window.localStorage)
		{
			var data = null;//JSON.parse(window.localStorage.getItem('db'));
			if (window.__server_data!=undefined)
			{
				data = window.__server_data;
				this.data = data;
				angular._app_type = data.user.type;
			}
			if (data==undefined || data==null)
				this.data = this.dataModel;
			if (angular._app_type)
				this.data.user.type = angular._app_type;
			return this.data;
		}
		return false;
	}

	this.update = function(next)
	{
		if (window.localStorage)
			window.localStorage.setItem('db',JSON.stringify(this.data));
		// update server
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_set_data',
				userID: this.data.user.id,
				data: JSON.stringify(this.data)
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}


	var self = this;
	this.checkMessages = function()
	{
		var last = 0;
		for(var i in self.mensagens)
		{
			var m = self.mensagens[i];
			if (parseInt(m.id)>last)
				last = parseInt(m.id);
		}

		if (self.data.user && self.data.user.id)
		{
			self.getMessage( last.toString(), function(mensagens)
				{
					var novas = 0;
					for(var i in mensagens)
					{
						var m = mensagens[i];
						if (parseInt(m.id)>last)
						{
							novas ++;
							self.mensagens.unshift(m);

							if (navigator.notification)
								if (navigator.notification.vibrate)
									navigator.notification.vibrate(500);
						}
					}
					try
					{
						if (self._updateScope)
							self._updateScope.$apply();	
					} catch(e) {console.log(e);}
					
				});
		}
		window.setTimeout( self.checkMessages, 20000);
	}

	this.listarVans = function(uf,cidade,next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_vans_cidade',
				//userID: this.data.user.id,
				uf:uf,
				cidade:cidade
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	this.getProdutos = function(next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_get_produtos'
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	this.cadastrar = function(user,next)
	{
		user.action = 'ym_create_user';
		$.ajax({
			dataType:'json',
			type:'POST',
			data:user,
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next)
					next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	this.externalLogin = function(user)
	{
		window.open( this.SITE + '/wp-content/plugins/yellos_mobile/service.php?' +
			'user_login='+encodeURIComponent(user.first_name+'_'+user.last_name) +
			'&user_password='+ encodeURIComponent(user.user_password) +
			'&plano='+encodeURIComponent(user.plano)+
			'&__app_login=1'
			, '_system');
	}

	this.showSocialFrame = function()
	{
		window.open( 'https://www.facebook.com/yellosvans' , '_system');
	}

	this.updateScope = function(sc)
	{
		this._updateScope = sc;
	}

	this.updateAvatar = function(avatar, next)
	{
		var dt = this.data;
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_avatar',
				userID: this.data.user.id,
				avatar: avatar
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				if (next) next(data);
			},
			error: function( jqXHR, textStatus, errorThrown ) {  }
		});
	}

	this.uploadFile = function(name,data,scope,next)
	{
		var url = this.URL;
		var uid = this.data.user.id;
		var file = {
			name:(name==null)? 'Foto' : name,
			progress: 0,
			data: data,
			scope: scope,
			thumb: 'img/loading2.gif'
		};
		file._uploader = function(fileRef)
			{
				$.ajax({
					dataType:'json',
					type:'POST',
					data:{
						action: 'ym_upload',
						userID: uid,
						file: data,
						name: ((name==null)? 'Foto' : name)
					},
					url:url,

					xhrFields: {
						custom: fileRef,
						onprogress: function(evt)
						{
							if (evt.lengthComputable)
							{
								//console.log(evt);
								//console.log(evt.loaded / evt.total * 100 + '%');
								//evt.currentTarget.custom.progress = parseInt(evt.loaded / evt.total * 100);
								//evt.currentTarget.custom.scope.$apply();
								//console.log(evt.currentTarget.custom.scope,evt.currentTarget.custom.progress);
								//console.log(evt.currentTarget.custom);
								fileRef.progress = parseInt(evt.loaded / evt.total * 100);
								fileRef.scope.$apply();
							}
						}
					},
					success: function( data, textStatus, jqXHR )
					{
						fileRef.thumb  = 'img/done.png'
						fileRef.progress = 100;
						fileRef.scope.$apply();

					},
					error: function( jqXHR, textStatus, errorThrown )
					{
						fileRef.thumb  = 'img/erro.png'
						fileRef.progress = 100;
						fileRef.scope.$apply();
					}
				});
			};
		file._uploader(file);
		if (next) next(file);
	}

	this.social = function(next)
	{
		$.ajax({
			dataType:'json',
			type:'POST',
			data:{
				action: 'ym_social',
			},
			url:this.URL,
			success: function( data, textStatus, jqXHR )
			{
				console.log(data);
				if (next)
					next(data.html);
			},
			error: function( jqXHR, textStatus, errorThrown ) { console.log(textStatus) }
		});
	}

	// start
	this.get();
	// first attemp to message board
	
	window.setTimeout(this.checkMessages, 5000);


	// dev fake data
	
	/*this.data = {
		user: {
			username: 'ze',
			password: null,
			type: 1, // 0 - usuario 1 - motorista
			nomeCompleto: 'MarcosB',
			tratamento: 'Tio',
			apelido: 'Eu',
			cel:'',
			email: 'mail@nada',
		},
		criancas: [
			{id:1, nome:'Joaozinho', nascimento:'20/12/2010', endereco:'R. Ceará, 126, Caçapava, SP', geolocation:{latitude:-23.068828,longitude:-45.713206}, complemento:'bairro dos doces', escola:0, periodo:'Manhã' },
			{id:2, nome:'Maria', nascimento:'20/12/2009', endereco:'R. Olávio Bilac, 155, Caçapava, SP', geolocation:{latitude:-23.074869,longitude:-45.713249}, complemento:'bairro dos doces', escola:0, periodo:'Manhã' },
			{id:3, nome:'Odilaldo', nascimento:'20/12/2004', endereco:'R. Dr. Alberto Morais Borges, 68, Caçapava, SP', geolocation:{latitude:-23.078659,longitude:-45.718184}, complemento:'bairro dos doces', escola:0, periodo:'Manhã' },
		],
		bairros: [
			{id:1, uf:'SP',cidade:'Areias', bairro:'Azeitona'}
		],
		escolas: [
			{id: 1,nome:'EE Jose das Candanga', endereco:'Rua dos bobos, n 0', telefone:'(12) 922342122'}
		],
	};*/

	/*this.data = {
		user: {
			username: 'zeca',
			password: null,
			type: 0, // 0 - usuario 1 - motorista
			nomeCompleto: 'MarcosB',
			cel:'',
			email: 'mail@nada',
		},
		criancas: [
			{id:1, nome:'Joaozinho', nascimento:'20/12/2010', endereco:'R. Ceará, 126, Caçapava, SP', geolocation:{latitude:-23.068828,longitude:-45.713206}, complemento:'bairro dos doces', escola:0, periodo:'Manhã' },
			{id:2, nome:'Maria', nascimento:'20/12/2009', endereco:'R. Olávio Bilac, 155, Caçapava, SP', geolocation:{latitude:-23.074869,longitude:-45.713249}, complemento:'bairro dos doces', escola:0, periodo:'Manhã' },
			{id:3, nome:'Odilaldo', nascimento:'20/12/2004', endereco:'R. Dr. Alberto Morais Borges, 68, Caçapava, SP', geolocation:{latitude:-23.078659,longitude:-45.718184}, complemento:'bairro dos doces', escola:0, periodo:'Manhã' },
		],
		bairros: [
			{id:1, uf:'SP',cidade:'Areias', bairro:'Azeitona'}
		],
		escolas: [
			{id: 1,nome:'EE Jose das Candanga', endereco:'Rua dos bobos, n 0', telefone:'(12) 922342122'}
		],
	};*/

	this.mensagens = [];
}

