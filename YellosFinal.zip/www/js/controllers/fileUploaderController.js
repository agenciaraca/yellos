function fileUploaderController($scope,$routeParams,$location,$http, $sessionHandler)
{

	console.log($scope);
	

	$scope.progressUpdate = function()
	{
		var v = $scope.$parent.file.progress;
		v +=10;
		if (v>100) v = 0;
		$scope.$parent.file.progress = v;
		if ($scope.$root.$$phase == '$apply' || $scope.$root.$$phase == '$digest')
		{} else $scope.$apply();
		window.setTimeout($scope.progressUpdate,180);
	}

	//$scope.progressUpdate();
}
