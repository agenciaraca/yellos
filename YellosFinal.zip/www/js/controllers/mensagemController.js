function mensagemController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'main';

	$scope.data = $sessionHandler.data;
	$scope.mensagens = $sessionHandler.mensagens;
	$scope.tab = 0;

	$scope.mensagem = {
		availableOptions:[],
		selected_to: null,
		extra: 0
	};
	if ($routeParams.extra)
		$scope.mensagem.extra = $routeParams.extra;

	$sessionHandler.updateScope($scope);


	$scope.isAlert = ($location.$$path.indexOf('alert')>-1) ? true : false;

	$('#main_menu').scope().set({use:false}).hide();

	if ($location.$$path.indexOf('edit')>-1)
	{
		if ($routeParams.to==undefined)
		{
			$sessionHandler.getToList(function(data)
				{
					console.log(data);
					$scope.mensagem.availableOptions = data;
					$scope.mensagem.selected_to = data[0];
					$scope.$apply();
				});
		} else {
			$scope.mensagem.selected_to = {ID:parseInt($routeParams.to),display_name:$routeParams.nome};
			$scope.mensagem.assunto = $routeParams.title;
			$scope.mensagem.texto = $routeParams.body;
		}
	}
	/*else
		$sessionHandler.getMessage(function(data)
			{
				console.log(data);
				$scope.mensagens = data;
				$scope.$apply();
			});*/

	$scope.adicionarCriancas = function(mensagem)
	{
		var m = mensagem;
		m.show_add_crianca = true;
		$('#esperar').show();
		$sessionHandler.getCriancasListFromPai(mensagem.de, function(data)
			{
				$('#esperar').hide();
				m.criancas_list = data;
				$scope.$apply();
			});
	}
	
	$scope.adicionarCriancas_end = function(mensagem,crianca)
	{
		$('#esperar').show();
		var _c = crianca;
		var total = 1 + $sessionHandler.data.criancas.length;
		if (total>=$sessionHandler.data.max_criancas)
		{
			$('#esperar').hide();
			alert("Seu plano de " + $sessionHandler.data.max_criancas + " esta cheio.");
			return;
		}

		$sessionHandler.data.criancas.push(crianca);

		$sessionHandler.update(function(d)
		{
			$('#esperar').hide();
			_c.is_hide = true;
			$scope.$apply();
		});
		return;
		$('#esperar').show();
		$sessionHandler.getCriancasListFromPai(mensagem.de, function(list)
			{
				var total = list.length + $sessionHandler.data.criancas.length;
				if (total>=$sessionHandler.data.max_criancas)
				{
					$('#esperar').hide();
					alert("Seu plano de " + $sessionHandler.data.max_criancas + " esta cheio.");
					return;
				}
			
				for (var i in list)
				{
					var c = list[i];
					$sessionHandler.data.criancas.push(c);
				}
				$sessionHandler.update(function(d)
					{
						$sessionHandler.deleteMessage(mensagem,function(result)
						{
							$('#esperar').hide();
							$location.path('crianca');
							$scope.$apply();
						});
						//$('#esperar').hide();
						//$location.path('crianca');
						//$scope.$apply();
					});
			});
	}

	$scope.adicionar = function()
	{
		$location.path('mensagem/edit');
	}

	$scope.salvar = function()
	{
		//$('#esperar').show();
		if(parseInt($scope.mensagem.selected_to.ID)==0)
		{
			$('#esperar').show();
			for(var i in $scope.mensagem.availableOptions)
			{
				var s = $scope.mensagem.availableOptions[i];
				if (s.ID!=0)
				{
					$scope.mensagem.selected_to = s;
					$sessionHandler.sendMessage($scope.mensagem,function(result)
					{
					});
				}
			}
			window.setTimeout(function() {
				$('#esperar').hide();
				window.location.href="#/mensagem";
			}, 5000);
		}
		else
			$sessionHandler.sendMessage($scope.mensagem,function(result)
				{
					$('#esperar').hide();
					//$scope.listar();
					//$location.path('mensagem/');
					window.location.href="#/mensagem";
				});
	}

	$scope.excluirMsg = function(mensagem)
	{
		$('#esperar').show();
		$sessionHandler.deleteMessage(mensagem,function(result)
			{
				$('#esperar').hide();
				//$scope.mensagens = result;
				//window.location.href="#/mensagem";
				/*var i=0;
				for(i=0;i<$scope.mensagens.length;i++)
					if ($scope.mensagens[i].id==mensagem.id) break;
				$scope.mensagens.splice(i,1);*/
				$scope.$apply();
			});
		
	}

	$scope.ativeTab = function(n)
	{
		$scope.tab = n;
	}

	$scope.isActiveTab = function(n)
	{
		if (n==$scope.tab) return 'active';
		return '';
	}
	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		//window.history.back();
		if ($location.$$path.indexOf('edit')>-1)
			$location.path('mensagem');
		else
			$location.path('main');
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}
}
