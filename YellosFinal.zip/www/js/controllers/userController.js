function userController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'user';


	$scope.data = $sessionHandler.data;
	$scope.user = {};

	$scope.files = [];


	$scope.take_avatar_foto = function($event)
	{
		var form = $event.currentTarget.parentNode;
		if (navigator.camera)
		{
			navigator.camera.getPicture(
				function (data)
				{
					$('#esperar').show();
					var src = 'data:image/jpeg;base64,' + data;
					$sessionHandler.updateAvatar(src,function(dt)
						{
							$('#esperar').hide();
							if (dt.ok)
							{
								$('#avatar').attr('src', src);
							}
						});
				},
				function (obj)
				{
					console.log("falha",obj);
				},
				{
					quality: 80,
					destinationType: Camera.DestinationType.DATA_URL,
					targetWidth: 96,
					targetHeight: 96,
					allowEdit : true,
					saveToPhotoAlbum: false
				});
		}
	}

	$scope.take_document_foto = function($event)
	{
		var form = $event.currentTarget.parentNode;
		if (navigator.camera)
		{
			navigator.camera.getPicture(
				function (data)
				{
					//$('#esperar').show();
					var src = /*'data:image/jpeg;base64,' +*/ data;
					$sessionHandler.uploadFile(null,data, $scope, function(_data)
					{
						$scope.files.push(_data);
						$scope.$apply();
					});
				},
				function (obj)
				{
					console.log("falha",obj);
				},
				{
					quality: 80,
					destinationType: Camera.DestinationType.DATA_URL,
					//targetWidth: 96,
					//targetHeight: 96,
					allowEdit : false,
					saveToPhotoAlbum: false
				});
		} else {
			var file = $('#sendTest')[0].files[0];
			var reader  = new FileReader();
			reader.addEventListener("load", function(e)
			{
				$sessionHandler.uploadFile(null,reader.result.toString().split(',')[1], $scope, function(data)
					{
						$scope.files.push(data);
						$scope.$apply();
					});
			}, false);

			if (file) reader.readAsDataURL(file);
		}
	}

	$scope.take_foto = function($event,w,h)
	{
		var form = $event.currentTarget.parentNode;
		if (navigator.camera)
		{
			navigator.camera.getPicture(
				function (data)
				{
					if (w!=null)
					{
						$('#esperar').show();
						var src = 'data:image/jpeg;base64,' + data;
						$sessionHandler.updateAvatar(src,function(dt)
							{
								$('#esperar').hide();
								if (dt.ok)
								{
									$('#avatar').attr('src', src);
								}
							});
					}
				},
				function (obj)
				{
					console.log("falha",obj);
				},
				{
					quality: 80,
					destinationType: Camera.DestinationType.DATA_URL,
					targetWidth: w,
					targetHeight: h,
					allowEdit : true,
					saveToPhotoAlbum: false
				});
		}
	}

	$scope.sendDocs = function()
	{
		$location.path('/user/upload');
	}
	
	//$('#main_menu').scope().set({use:false}).hide();

	$scope.logout = function ()
	{
		$sessionHandler.logout(function()
			{
				$location.path('/');
			});
	}
	
	$scope.salvar = function()
	{
		$scope.user['billing_city'] = $scope.selectedCidade;
		$scope.user['billing_state'] = $scope.selectedEstado;

		$scope.user['billing_state'] = $('#s_estado').val().split(',')[0];
		$scope.user['billing_city'] = $('#s_cidade').val().split(':')[1];
		
		$('#esperar').show();
		$sessionHandler.updateUser($scope.user, function(dt)
			{
				$('#esperar').hide();
			});
	}

	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		window.history.back();
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}


	$scope.estados = window.estados.uf;
	$scope.estado = $scope.estados[1];
	$scope.cidades = window.estados.cidades;
	$scope.cidade = $scope.cidades[1];
	$scope.selectedCidade = $scope.cidade[0];

	$scope.selectedEstado = 'DF';

	$scope.selectEstado = function(e)
	{
		var tg = $('#s_estado').val().split(',')[0];
		var i;
		for(i=0; i<$scope.estados.length; i++)
			if ($scope.estados[i][0]==tg)
				break;
		$scope.cidade = $scope.cidades[i];
		$scope.selectedCidade = $scope.cidade[1];
		$scope.selectedEstado = tg;
		//$scope.main.uf = $scope.estados[i][0];
		//$scope.main.cidade = $scope.selectedCidade;
		//	$scope.updateLista();
	}

	$scope.selectCidade = function()
	{
		console.log($scope.selectedCidade);
		//$scope.main.cidade = $scope.selectedCidade;
		//$scope.updateLista();
	}
	
	//$sessionHandler.data.user = {id:12,type:0};
	$sessionHandler.getUser(function(data)
		{
			console.log(data);
			$scope.user = data;
			var i = 0;
			for(i=1;i<$scope.estados.length;i++)
				if ($scope.estados[i][0]==data.billing_state) break;
			$scope.estado = $scope.estados[i];
			$scope.cidade = $scope.cidades[i];
			var i2 = 0;
			for(i2=1;i2<$scope.cidades[i].length;i2++)
				if ($scope.cidades[i][i2]==data.billing_city) break;
			
			//console.log(data.billing_state,$scope.cidades[i][i2]);
			console.log($scope.user.ym_avatar);
			$('#avatar').attr('src', $scope.user.ym_avatar);
			$scope.$apply();
			//$scope.selectedCidade = data.billing_city;
			$('#s_cidade')[0].selectedIndex = i2;
		});
}
