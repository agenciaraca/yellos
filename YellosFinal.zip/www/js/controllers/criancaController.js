function criancaController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'crianca';

	$scope.data = $sessionHandler.data;
	$scope.crianca = ($sessionHandler.updateCrianca!=undefined) ? $sessionHandler.updateCrianca : {};
	//if (!$scope.crianca.nome)
	//	$scope.crianca.nome = '';
	console.log($scope.crianca);
	console.log($sessionHandler.updateCrianca);

	for(var i in $scope.data.criancas)
		delete $scope.data.criancas[i].mensagemSended;

	$scope.problem = {status:false,title:'',message:'',btTitle:'',callback:null}

	$('#main_menu').scope().set({use:false}).hide();

	$scope.periodo = {
		options: [{value:0,name:'Todos'},{value:1,name:'Manhã'},{value:2,name:'Tarde'},{value:3,name:'Noite'}],
		selected: null
	};

	$scope.map = {
		center:
		{
			latitude: -13.5379603,
			longitude: -71.5954615,
		},
		zoom: 4
	};

	// seleciona o periodo pela hora
	var h = new Date().getHours();
	var i = 0;
	if (h<13)
		i=1;
	else
	if (h<19)
		i=2;
	else
	if (h>=19)
		i=3;
	//if ($scope.data.user.type==1)
	//	$scope.periodo.selected = $scope.periodo.options[i];
	//else
		$scope.periodo.selected = $scope.periodo.options[0];

	// itens necessários
	if ($scope.data.bairros.length==0 && angular._app_type==1)
	{
		$scope.problem = {status:true,title:'Sem bairros cadastrados',message:'Cadastre um bairro para iniciar',btTitle:'Cadastrar bairro',callback:'addBairro'}
	}
	else 
	if ($scope.data.escolas.length==0 && angular._app_type==1)
	{
		$scope.problem = {status:true,title:'Sem escolas cadastradas',message:'Cadastre uma escola para iniciar',btTitle:'Cadastrar escola',callback:'addEscola'}
	}

	if (angular._app_type==0 && $scope.crianca.endereco==undefined)
	{
		$sessionHandler.getUser(function(dt)
			{
				console.log(dt);
				$scope.crianca.endereco = dt.billing_address_1 + ", " + dt.billing_city + ", " + dt.billing_state + ', Brasil';
				$scope.$apply();
				$scope.updateCriancaEnd();
			});
	}

	if ($location.$$path.indexOf('edit')>-1)
	{
		$sessionHandler.getUserInfo($scope.crianca.pai,function(data)
			{
				$scope.info = { pai: data};
				$scope.$apply();
			});
	}


	$scope.rota = function()
	{
		$sessionHandler.traceRota = $scope.crianca.geolocation;
		$location.path('/mapa');
	}


	$scope.updateCrianca = function(crianca)
	{
		$sessionHandler.updateCrianca = crianca;
		$location.path('crianca/edit');
	}


	$scope.updateCriancaEnd = function()
	{
		var end = $scope.crianca.endereco;
		if (end==undefined || end==null)
			return;

		$sessionHandler.localizeEnd(end,function(res)
			{//Rua Dr Celestino, 297, Cruzeiro, SP
				//console.log(res);
				if ($scope.crianca==undefined)
					$scope.crianca = {};
				if ($scope.crianca.geolocation==undefined)
					$scope.crianca.geolocation = {latitude:0,longitude:0};
				$scope.crianca.geolocation.latitude = parseFloat(res.geometry.location.lat);
				$scope.crianca.geolocation.longitude = parseFloat(res.geometry.location.lng);
				$scope.map.center = {
					latitude:$scope.crianca.geolocation.latitude,
					longitude:$scope.crianca.geolocation.longitude
				};
				$scope.map.zoom = 16;
			});
	}


	$scope.solveProblem = function()
	{
		if($scope.problem.callback)
		{
			console.log($scope.problem.callback);
			var c = $scope[$scope.problem.callback];
			c();
		}
	}

	$scope.editCrianca = function(crianca)
	{

	}

	$scope.embarque = function(crianca,tit,msg)
	{
		$('#esperar').show();
		var c = crianca;
		$sessionHandler.sendMessage({
			selected_to: {ID:crianca.pai},
			assunto:tit,
			texto: ( (msg.length>0) ? 'Seu filho(a) ' + crianca.nome + ' ' + msg : '' )
		},function(e) {
			$('#esperar').hide();
			c.mensagemSended = true;
		});
		$sessionHandler.data.embarcados.push( {pai_id:crianca.pai,nome:crianca.nome} );
		$sessionHandler.update(false);
	}

	$scope.salvar = function()
	{
		if ($sessionHandler.data.user.type==1)
		{
			$('#esperar').show();
			console.log($sessionHandler.data);
			$sessionHandler.update(function()
				{
					$('#esperar').hide();
					//$location.path('crianca');
					window.location.href = "#/crianca";
				});
		} else {
			$scope.crianca.pai = $sessionHandler.data.user.id;
			$sessionHandler.data.criancas.push($scope.crianca);
			$('#esperar').show();
			$sessionHandler.update(function()
				{
					$('#esperar').hide();
					//$location.path('crianca');
					window.location.href = "#/crianca";
				});
		}
	}

	$scope.addEscola = function()
	{
		$location.path('escola/edit');
	}

	$scope.addBairro = function()
	{
		$location.path('bairro/edit');
	}


	$scope.adicionar = function()
	{
		$scope.crianca = {};
		$sessionHandler.updateCrianca = {};
		if ($sessionHandler.data.criancas.length>=$sessionHandler.data.max_criancas)
			alert("Seu plano de " + $sessionHandler.data.max_criancas + " esta cheio.");
		else 
			$location.path('crianca/edit');
	}

	$scope.excluir = function()
	{
		$('#esperar').show();
		var i = 0;
		for(i=0; i<$sessionHandler.data.criancas.length;i++)
			if ($sessionHandler.data.criancas[i].nome == $scope.crianca.nome)
				break;
		$sessionHandler.data.criancas.splice(i,1);
		$sessionHandler.update(function(d)
			{
				$('#esperar').hide();
				$location.path('crianca');
				$scope.$apply();
			});
	}

	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		//window.history.back();
		if ($location.$$path.indexOf('edit')>-1)
			$location.path('crianca');
		else
			$location.path('main');
	}
	
	//$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}

	$scope.$watch(function()
	{
		$('.angular-google-map-container').css(
		{
			'height':100,
		});
	});
}
