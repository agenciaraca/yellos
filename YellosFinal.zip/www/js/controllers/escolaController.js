function escolaController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'escola';

	$scope.data = $sessionHandler.data;
	$scope.escola = ($sessionHandler.escola) ? $sessionHandler.escola : {};

	$('#main_menu').scope().set({use:false}).hide();

	$scope.salvar = function()
	{
		if ($scope.escola.isInEdit)
		{
			$('#esperar').show();
			$sessionHandler.update(function()
				{
					$('#esperar').hide();
					window.location.href = "#/escola";
				});
		} else {
			$sessionHandler.data.escolas.push($scope.escola);
			$('#esperar').show();
			$sessionHandler.update(function()
				{
					$('#esperar').hide();
					window.location.href = "#/escola";
				});
		}
	}

	$scope.apagar = function()
	{
		var i = 0;
		for(i=0;i<$sessionHandler.data.escolas.length;i++)
			if ($sessionHandler.data.escolas[i].nome==$scope.escola.nome)
				break;
		$sessionHandler.data.escolas.splice(i,1);
		$('#esperar').show();
		$sessionHandler.update(function()
			{
				$('#esperar').hide();
				window.location.href = "#/escola";
			});
	}

	$scope.callF = function(escola)
	{
		if (window.plugins)
			if (window.plugins.CallNumber)
				window.plugins.CallNumber.callNumber(function(result){}, function(resultError) {}, escola.telefone, true);
	}


	$scope.editar = function(escola)
	{
		escola.isInEdit = true;
		$sessionHandler.escola = escola;
		$location.path('escola/edit');
	}

	$scope.adicionar = function()
	{
		delete $sessionHandler.escola;
		$location.path('escola/edit');
	}

	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		//window.history.back();
		if($location.$$path.indexOf('edit')>-1)
			$location.path('escola');
		else
			$location.path('main');
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}
}
