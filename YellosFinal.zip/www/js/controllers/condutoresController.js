function condutoresController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'condutores';

	$scope.data = $sessionHandler.data;

	$scope.problem = {status:false,title:'',message:'',btTitle:'',callback:null}
	$scope.estados = window.estados.uf;
	$scope.estado = $scope.estados[1];
	$scope.cidades = window.estados.cidades;
	$scope.cidade = $scope.cidades[1];
	$scope.selectedCidade = $scope.cidade[0];
	$scope.bairros = ['todos os bairros'];
	$scope.selectedBairro = $scope.bairros[0];
	$scope.vans = [];
	$scope.loadedVans = [];
	$scope.isLoading = true;

	$scope.main = null;

	//$('#main_menu').scope().set({use:false}).hide();


	// itens necessários
	if ($scope.data.escolas.length==0)
	{
		$scope.problem = {status:true,title:'Sem escolas cadastradas',message:'Cadastre uma escola para iniciar',btTitle:'Cadastrar escola',callback:'addEscola'}
	}

	if ($scope.main==null)
	{
		//$sessionHandler.data.user = {id:4,type:0};
		$sessionHandler.getUser(function(dt)
			{
				if (dt.billing_city==undefined) dt.billing_city = '';
				$scope.main = {
					uf: dt.billing_state,
					cidade: dt.billing_city.latinize(),
					username: dt.first_name + ' ' + dt.last_name
				};
				
				var i = 0;
				for (i=0; i<$scope.estados.length;i++)
					if ($scope.estados[i][0]==$scope.main.uf)
						break;
				$scope.estado = $scope.estados[i];
				$scope.cidade = $scope.cidades[i];
				i=0;
				if ($scope.cidade==undefined) $scope.cidade = $scope.cidades[0];
				for (i=0; i<$scope.cidade.length;i++)
					if ($scope.cidade[i].latinize()==$scope.main.cidade)
						break;
				$scope.selectedCidade = $scope.cidade[i];
				$scope.updateLista();
				$scope.$apply();
			});
	}

	
	$scope.requisitar = function(van)
	{
		$location.path('mensagem/edit/'+van.id+'/'
			+van.nome+'/'
			+'Requisição de transporte'+'/'
			+$scope.main.username + ' gostaria de usar seus serviços.' + '/'
			+ '1');
	}

	$scope.updateLista = function()
	{
		$scope.isLoading = true;
		$scope.vans.length = 0;
		$sessionHandler.listarVans($scope.main.uf,$scope.main.cidade, function(data)
			{
				var bairros = [];
				for(var i1 in data)
				{
					var van = data[i1];
					for(var i2 in van.bairros)
					{
						var bairro = van.bairros[i2];
						if (bairros.indexOf(bairro.nome)==-1)
							bairros.push(bairro.nome);
					}
				}
				bairros.sort();
				bairros.unshift('Bairro - Todos');
				$scope.bairros = bairros;
				$scope.selectedBairro = $scope.bairros[0];

				$scope.vans = data;
				$scope.loadedVans = data;
				$scope.isLoading = false;
				$scope.$apply();
			});
	}

	$scope.filtraVans = function()
	{
		var a = [];
		for (var i in $scope.loadedVans)
			if ($scope.loadedVans[i].bairros.indexOf($scope.selectedBairro))
				a.push($scope.loadedVans[i]);
		$scope.vans = a;
	}

	$scope.selectEstado = function()
	{
		var i;
		for(i=0; i<$scope.estados.length; i++)
			if ($scope.estados[i][0]==$scope.estado[0])
				break;
		$scope.cidade = $scope.cidades[i];
		$scope.selectedCidade = $scope.cidade[0];
		$scope.main.uf = $scope.estados[i][0];
		$scope.main.cidade = $scope.selectedCidade;
		$scope.updateLista();
	}

	$scope.selectCidade = function()
	{
		$scope.main.cidade = $scope.selectedCidade;
		$scope.updateLista();
	}

	$scope.solveProblem = function()
	{
		if($scope.problem.callback)
		{
			console.log($scope.problem.callback);
			var c = $scope[$scope.problem.callback];
			c();
		}
	}

	$scope.addEscola = function()
	{
		$location.path('escola/edit');
	}


	$scope.adicionar = function()
	{
		$location.path('escola/edit');
	}

	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		window.history.back();
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}
}
