function bairroController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'bairro';

	$scope.data = $sessionHandler.data;
	$scope.bairro = $sessionHandler.bairro || {};

	$('#main_menu').scope().set({use:false}).hide();


	$scope.adicionar = function()
	{
		$location.path('bairro/edit');
	}

	$scope.salvar = function()
	{
		var tg = $('#s_estado').val().split(',')[1];
		$scope.bairro.estado = tg;
		$scope.bairro.cidade = $scope.selectedCidade;
		$sessionHandler.data.bairros.push($scope.bairro);

		$('#esperar').show();
		$sessionHandler.update(function()
			{
				$('#esperar').hide();
				window.location.href = "#/bairro";
			});
	}

	$scope.apagar = function()
	{
		var i = 0;
		for(i=0;i<$sessionHandler.data.bairros.length;i++)
			if ($sessionHandler.data.bairros[i].nome==$scope.bairro.nome)
				break;
		$sessionHandler.data.bairros.splice(i,1);
		$('#esperar').show();
		$sessionHandler.update(function()
			{
				$('#esperar').hide();
				window.location.href = "#/bairro";
			});
	}

	$scope.editar = function(bairro)
	{
		$sessionHandler.bairro = bairro;
		$location.path('bairro/edit');
	}

	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		if($location.$$path.indexOf('edit')>-1)
			$location.path('bairro');
		else
			$location.path('main');
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}



	// combo
	$scope.estados = window.estados.uf;
	$scope.estado = $scope.estados[1];
	$scope.cidades = window.estados.cidades;
	$scope.cidade = $scope.cidades[1];
	$scope.selectedCidade = $scope.cidade[0];
	$scope.main = {uf:'',cidade:''};
	$scope.selectEstado = function(e)
	{
		var tg = $('#s_estado').val().split(',')[0];
		var i;
		for(i=0; i<$scope.estados.length; i++)
			if ($scope.estados[i][0]==tg)
				break;
		$scope.cidade = $scope.cidades[i];
		$scope.selectedCidade = $scope.cidade[1];
		//$scope.main.uf = $scope.estados[i][0];
		//$scope.main.cidade = $scope.selectedCidade;
		console.log($('#s_estado').val());
		console.log($scope.estado);
		console.log($scope.selectedCidade);
	}

	$scope.selectCidade = function(c)
	{
		//console.log(c);
		//$scope.main.cidade = $scope.selectedCidade;
		//console.log($scope.main);
	}
}
