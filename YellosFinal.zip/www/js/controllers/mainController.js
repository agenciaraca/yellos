function mainController($scope,$routeParams,$location,$http, $sessionHandler)																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																
{

	$scope.controllerName = 'main';

	$scope.data = $sessionHandler.data;

	$scope.mensagem = null;

	$scope.produtos = [];

	$scope.showPlanos = (angular._app_type==1) ? true : false;

	$scope.user = {};

	$scope.passwordMatch = true;


	delete $sessionHandler.traceRota;


	//if ($scope.data.isLogged && $location.$$path.indexOf('/login')>-1)
	//{
	//	$location.path('main');
	//}

	if (!$scope.data.id && $location.$$path.indexOf('/login')==-1 && $location.$$path.indexOf('/cadastro')==-1 && $location.$$path.indexOf('/seleciona')==-1)
	//	$location.path('login');
		$location.path('/');

	if ($location.$$path.indexOf('cadastro'))
	{
		$sessionHandler.getProdutos(function(list)
			{
				$scope.produtos = list;
				$scope.$apply();
			});
	}

	//$('#main_menu').scope().hide();

	$scope.match_pass = function()
	{
		$scope.passwordMatch = $scope.user.user_password == $scope.user.user_password2;
	}

	$scope.make_cadastro = function()
	{
		$scope.user.billing_state = $('#s_estado').val().split(",")[0];
		$scope.user.billing_city = $('#s_cidade').val().split(":")[1];
		if ($scope.user.plano==undefined && angular._app_type==1)
		{
			alert("Selecione um plano");
			return;
		}

		$('#esperar').show();
		$sessionHandler.cadastrar($scope.user, function(dt)
			{
				if (angular._app_type==1)
				{
					window.alert("Você sere redirecionado a nossa página de compras para confirmar a aquisição do plano.");
					$('#esperar').hide();
					$sessionHandler.externalLogin($scope.user);
					$location.path('/');
					$scope.$apply();
				} else {
					$scope.data.username = $scope.user.user_email;
					$scope.data.password = $scope.user.user_password;
					//$scope.logar();
					window.alert("Cadastro realizado.\nAgora você pode logar no aplicativo.");
					$('#esperar').hide();
					$location.path('/');
					$scope.$apply();
				}
			});
	}

	$scope.selectPlano = function(p)
	{
		for(var i in $scope.produtos)
			$scope.produtos[i].class = '';
		p.class = 'selPlano';
		$scope.user.plano = p.id;
	}


	$scope.logar = function()
	{
		/*if (angular._app_type==0)
		{
			$scope.data.username = 'marcos@yellos.com.br';
			$scope.data.password = '12345678';
		} else  {
			$scope.data.username = 'alex.jadanhi';
			$scope.data.password = '12345678';
		}*/

		//$scope.data.username = 'marcos@yellos.com.br';
		//$scope.data.password = '12345678';

		$('#esperar').show();
		$sessionHandler.login($scope.data.username,$scope.data.password, function(res,tx)
			{
				$('#esperar').hide();
				if (res!=false)
				{
					//$location.path('main');
					window.location.href="#/main";
				}
				else
				{
					$scope.mensagem = 'Login ou senha incorretos';
					$scope.$apply();
				}
			});
	}

	$scope.login = function()
	{
		$location.path('login');
	}

	$scope.lost_password = function()
	{
		if ($scope.data.username.indexOf('@')==-1)
		{
			alert("Insira um email válido");
			return;
		}
		$('#esperar').show();
		$sessionHandler.lost_password($scope.data.username,function(s)
			{
				$('#esperar').hide();
				alert("Uma nova senha foi enviada para seu email");
			});
	}

	$scope.sair=function()
	{
		if (window.confirm("Sair do sistema?"))
		{
			$sessionHandler.logout();
			window.location.reload();
		}
	}

	$scope.cadastrar = function()
	{
		$location.path('selecionacadastro');
		//window.location.href="#/cadastro";
	}

	$scope.cadastrar2 = function(v)
	{
		angular._app_type = v;
		$location.path('cadastro');
		//window.location.href="#/cadastro";
	}

	$scope.crianca = function()
	{
		$location.path('crianca');
	}

	$scope.mapa	= function()
	{
		$location.path('mapa');
	}

	$scope.mensagem = function()
	{
		$location.path('mensagem');
	}

	$scope.escola = function()
	{
		$location.path('escola');
	}

	$scope.bairro = function()
	{
		$location.path('bairro');
	}

	$scope.alerta = function()
	{
		$location.path('alerta');
	}
	
	$scope.user = function()
	{
		$location.path('user');
	}


	$scope.condutores = function()
	{
		$location.path('condutores');
	}

	$scope.ajuda = function()
	{
		$location.path('ajuda');
	}

	$scope.social = function()
	{
		$location.path('social');
		//$sessionHandler.showSocialFrame();
	}

	$scope.loadHelp = function(dst)
	{
		$location.path('external/'+dst);
	}


	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		//window.history.back();
		if ($location.$$path.indexOf('ajuda')>-1 || $location.$$path.indexOf('external')>-1)
			$location.path('main');
		else
			$location.path('/');
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}

	// combo
	$scope.estados = window.estados.uf;
	$scope.estado = $scope.estados[1];
	$scope.cidades = window.estados.cidades;
	$scope.cidade = $scope.cidades[1];
	$scope.selectedCidade = $scope.cidade[0];
	$scope.main = {uf:'',cidade:''};
	$scope.selectEstado = function(e)
	{
		var tg = $('#s_estado').val().split(',')[0];
		var i;
		for(i=0; i<$scope.estados.length; i++)
			if ($scope.estados[i][0]==tg)
				break;
		$scope.cidade = $scope.cidades[i];
		$scope.selectedCidade = $scope.cidade[1];
		//$scope.main.uf = $scope.estados[i][0];
		//$scope.main.cidade = $scope.selectedCidade;
		console.log($('#s_estado').val());
		console.log($scope.estado);
		console.log($scope.selectedCidade);
	}

	$scope.selectCidade = function(c)
	{
		//console.log(c);
		//$scope.main.cidade = $scope.selectedCidade;
		//console.log($scope.main);
	}

	// auto login
	if (window.localStorage)
	{
		if (window.__base)
		{
			$location.path('main');
			return;
		}
		var user = window.localStorage.getItem('user');
		var pass = window.localStorage.getItem('pass');
		if($sessionHandler.isFirstLoad)
		{
			if (user!=undefined && user!='')
			{
				$scope.data.username = user;
				$scope.data.password = pass;
				$sessionHandler.isFirstLoad = false;
				$scope.logar();
			}
		}
	}
}
