function externalController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'external';


	var PATH = 'http://yellos.com.br/wp-content/themes/yellos/info.php?page=';

	var page='';
	if ($location.$$path.indexOf('duvidas')>-1)
	{
		$scope.pageName = 'Duvidas';
		page = PATH + 'duvidas';
	}
	if ($location.$$path.indexOf('temos_de_uso')>-1)
	{
		$scope.pageName = 'Termos de Uso';
		page = PATH + 'termos';
	}
	if ($location.$$path.indexOf('sobre')>-1)
	{
		$scope.pageName = 'Sobre';
		page = PATH + 'sobre';
	}
	if ($location.$$path.indexOf('fale_conosco')>-1)
	{
		$scope.pageName = 'Fale Conosco';
		page = PATH + 'fale';
	}
	if ($location.$$path.indexOf('social')>-1)
	{
		$scope.pageName = 'Social';
		page = PATH + 'social';
	}

	if ($location.$$path.indexOf('social')>-1)
	{
		$sessionHandler.social(function(html)
		{
			$('#external').contents().find("body").html(html);
		});
	} else {
		$('#external').contents().find("body").html("<div style=\"text-align:center;\"><img src=\"/img/loading.gif\" /></div>");
		$('#external').attr('src',page);
	}
	
	
	$scope.navigate_back = function()
	{
		window.history.back();
	}
	
	
	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}

	$scope.$watch(function()
	{
		var e = $('#external');
		e.css('height',$(window).height() - 16 - e.offset().top);
	});

}
