function menuController($scope,$routeParams,$location,$http, $sessionHandler)
{

	$scope.controllerName = 'menu';


	$scope.data = $sessionHandler.data;

	$scope.navegation = {use:true, label:"voltar", link:null};

	$scope.display = "display:none;";

	window._menu = this.$scope;


	$scope.set = function(n)
	{	
		if (n)
		{
			if (n.use) $scope.navegation.use = n.use; else $scope.navegation.use = false;
			if (n.label) $scope.navegation.label = n.label; else $scope.navegation.label = "Voltar";
			if (n.link) $scope.navegation.link = n.link; else $scope.navegation.link = null;
		}
		return $scope;
	}

	$scope.back = function()
	{
		if ($scope.navegation.link==null)
			window.history.back();
		else
			$location.path($scope.navegation.link);
	}

	$scope.show = function()
	{
		$scope.display = "display:block;";
	}

	$scope.hide = function ()
	{
		$scope.display = "display:none;";
	}

	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		window.history.back();
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}
}
