function mapaController($scope,$routeParams,$location,$http, $sessionHandler, uiGmapIsReady)
{

	$scope.controllerName = 'mapa';

	$scope.data = $sessionHandler.data;

	$scope.problem = {status:false,title:'',message:'',btTitle:'',callback:null}

	$scope.isShowInfo = 'display:none';

	$scope.__error_integrity = false;

	if ($scope.data.user.type==1)
	{
		$scope.criancas = $scope.data.criancas;
	}

	$scope.marker_options = {draggable: false, icon: 'img/crianca.png'};

	$scope.criancas = [];
	$scope.vans = [];


	$scope.marker_events = {
		click: function(marker,eventName,args)
		{
			if ($sessionHandler.data.user.type==0)
				$scope.click_marker(marker, eventName, $scope.marker);
			else
				$scope.click_marker_crianca(marker, eventName, $scope.marker);
		}
	};

	//$('#main_menu').scope().set({use:false}).hide();

	$scope.map = {
		center:
		{
			latitude: -15.8142638,
			longitude: -47.9533445,
		},
		zoom: 10,
		markersControl: {}
	};

	$scope.marker = {};

	uiGmapIsReady.promise(1).then(function(instances)
	{
		instances.forEach(function(inst)
		{
			$scope.mapInstance = inst.map;
			$scope.locateMe();
		});
	});

	$scope.checkVan = function()
	{
		$sessionHandler.localizeVan(function(data)
			{
				// test
				//data = [{latitude:-23.068688, longitude:-45.714052},{latitude:-23.075756, longitude:-45.710576}];
				var bounds = {southwest:{latitude:14.443270,longitude:-86.577933}, northeast:{latitude:-54.362590,longitude:-36.656061}}
				var center = {latitude:0,longitude:0};
				for (var i in data)
				{
					var p = data[i];
					var lat = parseFloat(p.latitude);
					var lng = parseFloat(p.longitude);
					if (lat>bounds.northeast.latitude)
						bounds.northeast.latitude = lat;
					if (lng>bounds.northeast.longitude)
						bounds.northeast.longitude = lng;
					if (lat<bounds.southwest.latitude)
						bounds.southwest.latitude=lat;
					if (lng>bounds.southwest.longitude)
						bounds.southwest.longitude = lng;
					center.latitude += lat;
					center.longitude += lng;
				}
				center.latitude = center.latitude/data.length;
				center.longitude = center.longitude/data.length;

				if ($scope.vans.length<data.length)
				{
					for(var i in data)
					{
						var p = data[i];
						var lat = parseFloat(p.latitude);
						var lng = parseFloat(p.longitude);
						$scope.vans.push({
							id: $scope.vans.length+1,
							geolocation: { latitude: lat, longitude: lng},
							options: {draggable: false, icon: 'img/van.png' },
							showWindow: false,
						});
					}
					//console.log($scope.vans);
				}

				//console.log(data);
				if (data.length>0)
				{
					var van = data[0];
					$scope.marker.coords.latitude = parseFloat(van.latitude);
					$scope.marker.coords.longitude = parseFloat(van.longitude);
					$scope.map.center.latitude = center.latitude; // parseFloat(van.latitude);
					$scope.map.center.longitude = center.longitude; // parseFloat(van.longitude);
					$scope.$apply();
				}
				//delete $scope.map.center;
				//$scope.map.bounds = bounds;
			});

		window.setTimeout($scope.checkVan, 15000);
	}

	$scope.location_onSuccess = function(position)
	{
		$scope.__error_integrity = true;

		$scope.map = {
			center:{
				latitude: parseFloat(position.coords.latitude),
				longitude: parseFloat(position.coords.longitude)
			},
			zoom:15
		};
		
		$scope.marker = {
			id:0,
			coords: { latitude: parseFloat(position.coords.latitude), longitude: parseFloat(position.coords.longitude)},
			options: {draggable: false, icon: 'img/van.png' },
			//events: {
				//click: function(marker,eventName,args) { $scope.click_marker(marker, eventName, $scope.marker); }
			//},
			showWindow: false,
		};

		//$sessionHandler.traceRota = {latitude: -23.086496, longitude: -45.710148};
		if ($sessionHandler.traceRota)
		{
			$scope.directionsService = new google.maps.DirectionsService;
			$scope.directionsDisplay = new google.maps.DirectionsRenderer;
			$scope.directionsDisplay.setMap($scope.mapInstance);

			$scope.directionsService.route({
				origin: {lat:$scope.map.center.latitude, lng:$scope.map.center.longitude},
				destination: {lat:$sessionHandler.traceRota.latitude,lng:$sessionHandler.traceRota.longitude},
				travelMode: google.maps.TravelMode.DRIVING
			}, function(response, status){
				if (status === google.maps.DirectionsStatus.OK)
				{
					$scope.directionsDisplay.setDirections(response);
				}
			});
		}

		var criancas = [];
		for(var i in $sessionHandler.data.criancas)
		{
			try
			{
				var c = $sessionHandler.data.criancas[i];
				criancas.push({
					id: criancas.length+1,
					geolocation: c.geolocation, //{ latitude: parseFloat(c.geolocation.latitude), longitude: parseFloat(c.geolocation.longitude)},
					options: {draggable: false, icon: 'img/crianca.png' },
					//events: {
					//	click: function(marker,eventName,args) { $scope.click_marker_crianca(marker, eventName, $scope.marker); }
					//},
					showWindow: false,
				});
			} catch(e) {}
		}
		$scope.criancas = criancas;

		$scope.$apply();

		// update position of van
		if ($sessionHandler.data.user.type==1)
		{
			$sessionHandler.updatePosition( parseFloat(position.coords.latitude), parseFloat(position.coords.longitude) );
			if (!$sessionHandler.traceRota)
			{
				window.setTimeout(function() { $scope.locateMe(); }, 15000);
			}

			$scope.marker.coords.latitude = parseFloat(position.coords.latitude);
			$scope.marker.coords.longitude = parseFloat(position.coords.longitude);
			$scope.map.center.latitude = parseFloat(position.coords.latitude);
			$scope.map.center.longitude = parseFloat(position.coords.longitude);
			$scope.$apply();
		}
	}

	$scope.location_onError = function(error)
	{
		$scope.__error_integrity = true;
		console.log("error");
		console.log(error); // error.code error.message
		window.alert("Ative o GPS do seu dispositivo para iniciar o rastreio");
		$location.path('main');
	}

	
	$scope.click_marker = function(marker, eventName, args)
	{
		/*var child = null;
		for (var i in $scope.data.criancas)
		{
			var c = $scope.data.criancas[i];
			if (c.id == parseInt(marker.key))
			{
				child = c;
				break;
			}
		}
		if (child)
		{
			$scope.selected = child;
			$scope.isShowInfo = 'display:flex';
		}*/
		console.log(marker);
	}

	$scope.click_marker_crianca = function(marker, eventName, args)
	{
		var child = $sessionHandler.data.criancas[marker.key-1];

		$scope.selected = {
			crianca: child,
			nome: child.nome,
			endereco: child.endereco
		};
		$scope.isShowInfo = 'display:table-cell';
		console.log(child);
		$scope.clickedMarker = marker;
	}

	$scope.confirmarEmbarque = function()
	{
		return;
		$sessionHandler.sendMessage({
			selected_to: {ID:$scope.selected.crianca.pai},
			assunto:'Embarque confirmado',
			texto: 'Seu filho(a) ' + $scope.selected.crianca.nome + ' acabou de embarcar.'
		});
		$sessionHandler.data.embarcados.push( {pai_id:$scope.selected.crianca.pai,nome:$scope.selected.crianca.nome} );
		$sessionHandler.update(false);
		$scope.removeSelMarker();
		$scope.isShowInfo = 'display:none';
	}

	$scope.desembarcar = function()
	{
		if(window.confirm("Confirmar desembarque das crianças?"))
		{
			$('#esperar').show();
			for(var i in $sessionHandler.data.embarcados)
			{
				var child = $sessionHandler.data.embarcados[i];
				$sessionHandler.sendMessage({
					selected_to: {ID:child.pai_id},
					assunto:'Seu filho chegou ao destino',
					texto: 'Seu filho(a) ' + child.nome + ' chegou ao destino.'
				});
			}
			$sessionHandler.data.embarcados=[];
			$sessionHandler.update(function(d)
			{
				$('#esperar').hide();
			});
		}
	}

	$scope.reportarNaoEmbarque = function()
	{
		$sessionHandler.sendMessage({
			selected_to: {ID:$scope.selected.crianca.pai},
			assunto:'Não houve o embarque',
			texto: 'Seu filho(a) ' + $scope.selected.crianca.nome + ' não foi embarcado.'
		});
		$scope.removeSelMarker();
		$scope.isShowInfo = 'display:none';
	}

	$scope.removeSelMarker = function()
	{
		var i = 0;
		for(i=0;i<$scope.criancas.length; i++)
			if($scope.criancas[i].key==$scope.clickedMarker.key)
				break;
		//console.log($scope.clickedMarker.key);
		//console.log($scope.criancas.splice(i,1));
		//$scope.map.markersControl.managerDraw();
		//$scope.$apply();
	}

	$scope.locateMe = function()
	{
		navigator.geolocation.getCurrentPosition( $scope.location_onSuccess, $scope.location_onError);
	}

	$scope.adicionar = function()
	{
		$location.path('escola/edit');
	}

	
	$scope.navigate = function(dst)
	{
		$location.path(dst);
	}

	$scope.navigate_back = function()
	{
		window.history.back();
	}
	
	$scope.readOnly = ($location.$$path.indexOf('/show')>-1) ? true : false;

	$scope.onSwipeLeft = function()
	{
		console.log('desmostra u menu');
	}

	$scope.onSwipeRight = function()
	{
		angular.element($('body>nav')[0]).scope().show();
	}

	$scope.$watch(function()
	{
		var hd = $( $('body>main>nav')[0] );
		$('.angular-google-map-container').css(
		{
			'width':$(window).width(),
			'height':$(window).height() - hd.height() - 30 - ( (angular._app_type==1) ? 0 : 0 ),
			'left':'0px',
			'top':hd.offset().bottom,
			'position':'fixed',
			'z-index':'10000'
		});
		/*console.log(hd.height());
		if (hd.length)
			//$(hd[0].nextElementSibling).css('margin-top',hd.height());
			$('.angular-google-map-container').css( {
				'left':0,
				'top': hd.height(),
				'width': $(window).width(),
				'height': $(window).height() - hd.height()
			});*/
	});

	if (angular._app_type==0)
	{
		window.setTimeout($scope.checkVan, 5000);
	}

	if (angular._app_type==1)
	{
		window.setTimeout(function()
			{
				if(!$scope.__error_integrity)
				{
					$scope.__error_integrity = true;
					window.alert("Ative o GPS do seu dispositivo para iniciar o rastreio");
					$location.path('main');
				}
			}, 6000);
	}

}
